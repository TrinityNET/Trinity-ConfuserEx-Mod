﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Confuser.Runtime
{
    internal static class ModuleFlood
    {
        private static void Initialize()
        {
        }
    }
}
