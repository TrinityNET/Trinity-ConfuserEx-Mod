﻿using System;
using System.Reflection;

[assembly: AssemblyTitle("ConfuserEx Runtime")]
[assembly: AssemblyDescription("Runtime library of ConfuserEx")]