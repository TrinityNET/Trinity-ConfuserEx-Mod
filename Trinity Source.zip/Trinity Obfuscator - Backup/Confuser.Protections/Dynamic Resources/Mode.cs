﻿using System;

namespace Confuser.Protections.Resources2
{
    // Token: 0x02000050 RID: 80
    internal enum Mode
    {
        // Token: 0x040000A3 RID: 163
        Normal,
        // Token: 0x040000A4 RID: 164
        Dynamic
    }
}
