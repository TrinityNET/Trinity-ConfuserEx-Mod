﻿using System;

namespace Confuser.Protections.Resources {
	internal enum Mode {
		Normal,
		Dynamic
	}
}