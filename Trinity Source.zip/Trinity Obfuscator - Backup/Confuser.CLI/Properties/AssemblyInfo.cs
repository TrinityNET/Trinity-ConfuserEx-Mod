﻿using System;
using System.Reflection;

[assembly: AssemblyTitle("ConfuserEx Command-line")]
[assembly: AssemblyDescription("Command-line interface of ConfuserEx")]